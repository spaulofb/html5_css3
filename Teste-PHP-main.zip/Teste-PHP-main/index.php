<?php

    echo "hello world";

    phpinfo();
?>