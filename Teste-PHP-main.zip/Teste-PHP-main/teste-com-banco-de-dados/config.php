<?php
    $host     = "";
    $dbname   = "";
    $user     = "";
    $password = "";
?>
