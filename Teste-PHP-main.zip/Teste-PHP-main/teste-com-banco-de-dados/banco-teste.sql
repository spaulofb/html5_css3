CREATE TABLE `users`(
    user varchar(30)
)